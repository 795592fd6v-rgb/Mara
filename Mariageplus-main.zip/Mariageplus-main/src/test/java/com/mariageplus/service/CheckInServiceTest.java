package com.mariageplus.service;

import com.mariageplus.dto.checkin.CheckInRequest;
import com.mariageplus.dto.checkin.CheckInResponse;
import com.mariageplus.dto.checkin.CheckInScanResponse;
import com.mariageplus.dto.checkin.ScanCheckInRequest;
import com.mariageplus.entity.CheckIn;
import com.mariageplus.entity.Guest;
import com.mariageplus.entity.Invitation;
import com.mariageplus.entity.InvitationStatus;
import com.mariageplus.entity.Rsvp;
import com.mariageplus.entity.RsvpStatus;
import com.mariageplus.entity.Wedding;
import com.mariageplus.entity.WeddingStatus;
import com.mariageplus.exception.ConflictException;
import com.mariageplus.exception.ResourceNotFoundException;
import com.mariageplus.repository.CheckInRepository;
import com.mariageplus.repository.GuestRepository;
import com.mariageplus.repository.InvitationRepository;
import com.mariageplus.repository.RsvpRepository;
import com.mariageplus.repository.WeddingRepository;
import com.mariageplus.security.SecurityUtils;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

/**
 * Tests unitaires du check-in : permissions, scan, check-in, refus métier et
 * logique de verrouillage/anti-dépassement (recalcul de la somme via
 * {@link InvitationRepository#findByPublicTokenForUpdate}).
 */
@ExtendWith(MockitoExtension.class)
class CheckInServiceTest {

    @Mock private CheckInRepository checkInRepository;
    @Mock private InvitationRepository invitationRepository;
    @Mock private GuestRepository guestRepository;
    @Mock private WeddingRepository weddingRepository;
    @Mock private RsvpRepository rsvpRepository;
    @Mock private SecurityUtils securityUtils;
    @Mock private AuditService auditService;

    @InjectMocks private CheckInService checkInService;

    private Invitation invitation;
    private Wedding wedding;
    private Guest guest;

    @BeforeEach
    void setUp() {
        invitation = Invitation.builder()
                .guestId(7L).weddingId(1L).publicToken("tok").status(InvitationStatus.GENERATED).build();
        invitation.setId(5L);
        guest = Guest.builder().firstName("Jean").lastName("Kabongo")
                .weddingId(1L).allowedCompanions(2).build();
        guest.setId(7L);
        wedding = Wedding.builder()
                .groomFirstName("Jean").groomLastName("Kabongo")
                .brideFirstName("Marie").brideLastName("Mukendi")
                .status(WeddingStatus.DRAFT).build();
        wedding.setId(1L);
        wedding.setOrganizationId(100L);
    }

    private Rsvp acceptedRsvp(int attendees) {
        return Rsvp.builder().invitationId(5L).status(RsvpStatus.ACCEPTED).numberOfAttendees(attendees).build();
    }

    private CheckInRequest checkInRequest(int attendees) {
        CheckInRequest req = new CheckInRequest();
        req.setQrToken("tok");
        req.setNumberOfAttendees(attendees);
        return req;
    }

    private ScanCheckInRequest scanRequest() {
        ScanCheckInRequest req = new ScanCheckInRequest();
        req.setQrToken("tok");
        return req;
    }

    private void stubStateInvitation() {
        when(invitationRepository.findByPublicToken("tok")).thenReturn(Optional.of(invitation));
        when(weddingRepository.findById(1L)).thenReturn(Optional.of(wedding));
        when(guestRepository.findById(7L)).thenReturn(Optional.of(guest));
    }

    @Test
    void scan_requiresScanPermission() {
        doThrow(new SecurityException("denied")).when(securityUtils).assertPermission("CHECKIN_SCAN");
        assertThrows(SecurityException.class, () -> checkInService.scan(scanRequest()));
    }

    @Test
    void scan_returnsState_canCheckInTrue() {
        stubStateInvitation();
        when(rsvpRepository.findByInvitationId(5L)).thenReturn(Optional.of(acceptedRsvp(3)));
        when(checkInRepository.sumByInvitationId(5L)).thenReturn(2);

        CheckInScanResponse response = checkInService.scan(scanRequest());

        assertEquals("Jean Kabongo", response.getGuestName());
        assertEquals(3, response.getExpectedAttendees());
        assertEquals(2, response.getCheckedInAttendees());
        assertEquals(1, response.getRemainingAttendees());
        assertTrue(response.isCanCheckIn());
        assertEquals("ACCEPTED", response.getRsvpStatus());
    }

    @Test
    void scan_canCheckInFalse_whenNoRsvp() {
        stubStateInvitation();
        when(rsvpRepository.findByInvitationId(5L)).thenReturn(Optional.empty());
        when(checkInRepository.sumByInvitationId(5L)).thenReturn(0);

        CheckInScanResponse response = checkInService.scan(scanRequest());
        assertEquals(0, response.getExpectedAttendees());
        assertFalse(response.isCanCheckIn());
    }

    @Test
    void scan_unknownToken_404() {
        when(invitationRepository.findByPublicToken("unknown")).thenReturn(Optional.empty());
        ScanCheckInRequest req = new ScanCheckInRequest();
        req.setQrToken("unknown");
        assertThrows(ResourceNotFoundException.class, () -> checkInService.scan(req));
    }

    @Test
    void scan_cancelledInvitation_404() {
        invitation.setStatus(InvitationStatus.CANCELLED);
        when(invitationRepository.findByPublicToken("tok")).thenReturn(Optional.of(invitation));
        assertThrows(ResourceNotFoundException.class, () -> checkInService.scan(scanRequest()));
    }

    @Test
    void checkIn_requiresCreatePermission() {
        doThrow(new SecurityException("need")).when(securityUtils).assertPermission("CHECKIN_CREATE");
        assertThrows(SecurityException.class, () -> checkInService.checkIn(checkInRequest(1)));
    }

    @Test
    void checkIn_usesLockedQuery() {
        when(invitationRepository.findByPublicTokenForUpdate("tok")).thenReturn(Optional.of(invitation));
        when(weddingRepository.findById(1L)).thenReturn(Optional.of(wedding));
        when(rsvpRepository.findByInvitationId(5L)).thenReturn(Optional.of(acceptedRsvp(3)));
        when(checkInRepository.sumByInvitationId(5L)).thenReturn(1);
        when(checkInRepository.save(any(CheckIn.class))).thenAnswer(a -> a.getArgument(0));

        checkInService.checkIn(checkInRequest(1));

        verify(invitationRepository).findByPublicTokenForUpdate("tok");
        verify(invitationRepository, never()).findByPublicToken("tok");
    }

    @Test
    void checkIn_creates_whenCapacityAvailable() {
        when(invitationRepository.findByPublicTokenForUpdate("tok")).thenReturn(Optional.of(invitation));
        when(weddingRepository.findById(1L)).thenReturn(Optional.of(wedding));
        when(rsvpRepository.findByInvitationId(5L)).thenReturn(Optional.of(acceptedRsvp(3)));
        when(checkInRepository.sumByInvitationId(5L)).thenReturn(1);
        when(checkInRepository.save(any(CheckIn.class))).thenAnswer(a -> a.getArgument(0));

        CheckInResponse response = checkInService.checkIn(checkInRequest(2));

        ArgumentCaptor<CheckIn> captor = ArgumentCaptor.forClass(CheckIn.class);
        verify(checkInRepository).save(captor.capture());
        assertEquals(5L, captor.getValue().getInvitationId());
        assertEquals(Integer.valueOf(2), captor.getValue().getNumberOfAttendees());
        assertNotNull(captor.getValue().getCheckedInAt());
        assertEquals(3, response.getCheckedInAttendees());
        assertEquals(0, response.getRemainingAttendees());
    }

    @Test
    void checkIn_rejects_noRsvp() {
        when(invitationRepository.findByPublicTokenForUpdate("tok")).thenReturn(Optional.of(invitation));
        when(weddingRepository.findById(1L)).thenReturn(Optional.of(wedding));
        when(rsvpRepository.findByInvitationId(5L)).thenReturn(Optional.empty());

        assertThrows(ConflictException.class, () -> checkInService.checkIn(checkInRequest(1)));
        verify(checkInRepository, never()).save(any(CheckIn.class));
    }

    @Test
    void checkIn_rejects_declinedRsvp() {
        when(invitationRepository.findByPublicTokenForUpdate("tok")).thenReturn(Optional.of(invitation));
        when(weddingRepository.findById(1L)).thenReturn(Optional.of(wedding));
        when(rsvpRepository.findByInvitationId(5L)).thenReturn(Optional.of(
                Rsvp.builder().invitationId(5L).status(RsvpStatus.DECLINED).numberOfAttendees(0).build()));

        assertThrows(ConflictException.class, () -> checkInService.checkIn(checkInRequest(1)));
        verify(checkInRepository, never()).save(any(CheckIn.class));
    }

    @Test
    void checkIn_rejects_overrun_concurrentLike() {
        // RSVP = 3, déjà entré = 2, demande = 2 → 2 + 2 > 3 → refus (recalcul dans la transaction)
        when(invitationRepository.findByPublicTokenForUpdate("tok")).thenReturn(Optional.of(invitation));
        when(weddingRepository.findById(1L)).thenReturn(Optional.of(wedding));
        when(rsvpRepository.findByInvitationId(5L)).thenReturn(Optional.of(acceptedRsvp(3)));
        when(checkInRepository.sumByInvitationId(5L)).thenReturn(2);

        assertThrows(ConflictException.class, () -> checkInService.checkIn(checkInRequest(2)));
        verify(checkInRepository, never()).save(any(CheckIn.class));
    }

    @Test
    void checkIn_rejects_zeroAttendees() {
        // parseAttendees lève avant toute résolution (le 0/ négatif est refusé à l'entrée)
        assertThrows(IllegalArgumentException.class, () -> checkInService.checkIn(checkInRequest(0)));
        verify(checkInRepository, never()).save(any(CheckIn.class));
    }

    @Test
    void checkIn_rejects_wrongOrganization() {
        when(invitationRepository.findByPublicTokenForUpdate("tok")).thenReturn(Optional.of(invitation));
        when(weddingRepository.findById(1L)).thenReturn(Optional.of(wedding));
        doThrow(new SecurityException("hors périmètre")).when(securityUtils).assertOrganizationAccess(100L);

        assertThrows(SecurityException.class, () -> checkInService.checkIn(checkInRequest(1)));
        verify(checkInRepository, never()).save(any(CheckIn.class));
    }
}