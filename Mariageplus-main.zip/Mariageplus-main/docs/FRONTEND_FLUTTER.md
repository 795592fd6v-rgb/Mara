# Guide Frontend Mobile — Flutter (MariagePlus)

Interface officielle du backend Java/Spring Boot `com.mariageplus` (dossier `D:\Projet\mariageplus-backend`).

> Ce guide est **exact par rapport au backend réel** (endpoints, DTO, permissions, statuts HTTP). Le principe directeur demandé : **chaque écran / action est conditionné par la permission de l'utilisateur** (on n'affiche que ce que l'utilisateur a le droit d'utiliser).

---

## 1. Vue d'ensemble

| Élément | Valeur |
|---|---|
| Backend | Spring Boot 3.2 / Java 17, base H2 (local) / PostgreSQL (prod) |
| Authentification | **JWT Bearer** (header `Authorization: Bearer <token>`) |
| Format des réponses | JSON ; erreurs → `{ "error": "<message>" }` |
| Pagination | Réponses paginées → objet `PageResponse` commun |

### URL de base
- **Local (H2)** : `http://localhost:8000`  — lancement : `mvn spring-boot:run -Dspring-boot.run.profiles=local`
  - Emulateur Android : `http://10.0.2.2:8000`
  - Test sur navigateur/simulateur : `http://localhost:8000`
- **Production (PostgreSQL)** : `https://<votre-domaine>` (via les variables d'environnement).
- Swagger (lecture des contrats) : `http://localhost:8000/swagger-ui.html`

> ⚠️ En **profil local**, un compte SUPER_ADMIN de dev est créé : `admin@mariageplus.local / Admin@12345`. En **production**, il n'est PAS créé automatiquement (voir backend : `ADMIN_INIT_ENABLED=false` par défaut).

---

## 2. Authentification

### 2.1 Inscription : `POST /auth/register` (public)
```json
{
  "firstName": "Jean",
  "lastName": "Kabongo",
  "email": "jean@exemple.com",
  "phone": "+243810000000",
  "password": "motdepasse123",
  "organizationName": "Mon Organisation",
  "organizationEmail": "contact@exemple.com",
  "organizationPhone": "+243810000000",
  "organizationAddress": "Kinshasa"
}
```
- `password` : **min 8 caractères**.
- Réponse (comme login) : `LoginResponse` + auto-connexion.

### 2.2 Connexion : `POST /auth/login` (public)
```json
{ "email": "jean@exemple.com", "password": "motdepasse123" }
```
Réponse `LoginResponse` :
```json
{
  "token": "<JWT>",
  "expiresIn": 86400,
  "user": {
    "id": 1,
    "firstName": "Jean",
    "lastName": "Kabongo",
    "email": "jean@exemple.com",
    "phone": "+243810000000",
    "active": true,
    "emailVerified": true,
    "lastLoginAt": "2026-08-19T17:00:00",
    "roles": ["ORGANISATEUR"],
    "organizationId": 1
  }
}
```

### 2.3 Profil courant : `GET /auth/me` (JWT requis)
Renvoie l'utilisateur connecté (une seule fois au démarrage de l'app pour charger rôles + organisation).

### 2.4 Stockage & expiration du token (Flutter)
- Stocker le `token` et `expiresIn` en **stockage sécurisé** (ex. package `flutter_secure_storage`).
- Le backend renvoie `expiresIn` en **secondes** (défaut `86400` = 24 h).
- À chaque `401` reçu par l'intercepteur → invalider la session locale et rediriger vers l'écran de connexion.
- Ne **jamais** stocker le mot de passe.

> Le backend recrée le contexte de sécurité à partir de la base **à chaque requête** (rôles/permissions/organisation à jour) : si un compte est désactivé ou si les permissions changent, l'écart est pris en compte immédiatement côté serveur. L'app n'a pas besoin de stocker la liste des permissions localement de façon "source de vérité" ; elle peut la **mettre en cache** pour piloter l'affichage.

---

## 3. Cliente HTTP (dio) — recommandation

Ajouter `dio` (+ `flutter_secure_storage`) dans `pubspec.yaml`.

```dart
final dio = Dio(BaseOptions(
  baseUrl: 'http://localhost:8000',
  connectTimeout: const Duration(seconds: 15),
  receiveTimeout: const Duration(seconds: 20),
  headers: {'Content-Type': 'application/json'},
));

dio.interceptors.add(InterceptorsWrapper(
  onRequest: (options, handler) async {
    final token = await secureStorage.read(key: 'jwt');
    if (token != null && token.isNotEmpty) {
      options.headers['Authorization'] = 'Bearer $token';
    }
    handler.next(options);
  },
  onError: (e, handler) async {
    if (e.response?.statusCode == 401) {
      await secureStorage.delete(key: 'jwt');
      // rediriger vers /login
    }
    handler.next(e);
  },
));
```

### En-têtes
- Tous les endpoints **protégés** : header `Authorization: Bearer <token>`.
- Les endpoints **publics** (RSVP, register, login) : **sans** header JWT.


---

## 5. Modèles de données (DTO backend → Dart)

> Les dates JSON sont au format `LocalDateTime` (ex. `2026-08-19T17:00:00`) : les parser en `DateTime.parse()` en ajoutant `Z` si besoin pour l'affichage local. Les enums (statut) arrivent comme **strings** (en majuscules).

### 5.1 Réponse paginée (commune)
```dart
class PageResponse<T> {
  final List<T> content;
  final int currentPage;
  final int pageSize;
  final int totalElements;
  final int totalPages;
  // factory fromJson(map) : content = items.map(T.fromJson).toList()
}
```

### 5.2 Utilisateur / Login
```dart
class User {
  final int id;
  final String? firstName, lastName, email, phone;
  final bool active, emailVerified;
  final String? lastLoginAt;
  final List<String> roles;       // ex. ["ORGANISATEUR"]
  final int? organizationId;
}
class LoginResult { String token; int expiresIn; User user; }
```

### 5.3 Mariage (`WeddingResponse`)
```dart
class Wedding {
  final int id; final int organizationId;
  final String groomFirstName, groomLastName;
  final String brideFirstName, brideLastName;
  final String? groomPhotoUrl, bridePhotoUrl, couplePhotoUrl;
  final String? description, welcomeMessage;
  final String status;       // DRAFT/PUBLISHED/ACTIVE/COMPLETED/ARCHIVED/CANCELLED
  final String displayName;  // "Groom & Bride" (affichage souhaité)
  final String? createdAt, updatedAt;
}
```

### 5.4 Invité (`GuestResponse`)
`id, weddingId, categoryId?, firstName, lastName, phone?, email?, address?, allowedCompanions, notes?, active, createdAt, updatedAt`

**Création (`CreateGuestRequest`)** : `firstName*`, `lastName*`, `phone?`, `email?`, `address?`, `categoryId?`, `allowedCompanions?`, `notes?`.

### 5.5 Catégorie d'invités (`GuestCategoryResponse`)
`id, weddingId, name, description?, displayOrder?, active, createdAt, updatedAt`
**Création (`CreateGuestCategoryRequest`)** : `name*`, `description?`, `displayOrder?`.

### 5.6 Invitation administrative (`InvitationResponse`)
`id, weddingId, guestId, invitationCode, status, sentAt?, lastSentAt?, createdAt, updatedAt`
- `status` : `DRAFT / GENERATED / SENT / CANCELLED / EXPIRED`.
- ⚠️ Le `publicToken` **n'est pas** exposé par cette réponse (accès invité séparé).
- **Création (`CreateInvitationRequest`)** : `{ "guestId": <id> }` uniquement.

### 5.7 Accès public invité (`PublicInvitationResponse`)
```json
{
  "guestFirstName": "Alice",
  "guestLastName": "Ngoma",
  "weddingDisplayName": "Jean Kabongo & Marie Mukendi",
  "status": "GENERATED",          // statut invitation (GENERATED/SENT/DRAFT…)
  "rsvpStatus": null,             // ACCEPTED/DECLINED/null (null = pas de réponse)
  "rsvpNumberOfAttendees": null
}
```

### 5.8 RSVP public — soumission (`SubmitRsvpRequest`)
```json
{ "status": "ACCEPTED", "numberOfAttendees": 2 }
```
Règles serveur (à refléter côté UI) :
- `ACCEPTED` → `1 ≤ numberOfAttendees ≤ (1 + allowedCompanions de l'invité)`.
- `DECLINED` → `numberOfAttendees = 0` (valeur > 0 refusée `400`).
Réponse (`PublicRsvpResponse`) : `{ "invitationStatus", "rsvpStatus", "numberOfAttendees", "respondedAt" }`.

### 5.9 Check-in
- **Scan (`CheckInScanResponse`)** : `guestName, weddingDisplayName, invitationStatus, rsvpStatus, expectedAttendees, checkedInAttendees, remainingAttendees, canCheckIn`.
- **Enregistrement (`CheckInResponse`)** : `checkInId, guestName, weddingDisplayName, invitationStatus, rsvpStatus, numberOfAttendees, checkedInAt, expectedAttendees, checkedInAttendees, remainingAttendees`.
- **Requêtes** : `POST /api/checkins/scan` → `{ "qrToken": "...publicToken..." }` ; `POST /api/checkins` → `{ "qrToken": "...", "numberOfAttendees": 1 }`.

### 5.10 Table (`WeddingTableResponse`) & affectation
- **Table** : `id, name, description?, capacity, assignedCount, remainingCapacity`.
- **Affectation (`TableAssignmentResponse`)** : `assignmentId, guestId, guestName, tableId, tableName, assignedAt`.

### 5.11 QR (`QrCodeResponse`)
```json
{ "qrDataUri": "data:image/png;base64,...." }
```
Afficher directement avec un widget `Image.memory` après décodage base64 (partie après la virgule), ou `Image.network` si servi. Le **token brut n'est pas** renvoyé par l'API admin.

### 5.12 Dashboard (`WeddingDashboardResponse`)
```json
{
  "weddingId": 1, "weddingName": "Jean Kabongo & Marie Mukendi",
  "guests":      { "total": 100, "unassigned": 25 },
  "invitations": { "total": 100, "accepted": 60, "declined": 20, "pending": 20, "responseRate": 80.0 },
  "attendance":  { "expected": 90, "checkedIn": 70, "remaining": 20, "checkInRate": 77.78 },
  "tables":      { "total": 12, "capacity": 120, "assignedGuests": 75, "remainingCapacity": 45 },
  "categories": [
    { "categoryId": 2, "name": "Famille", "totalGuests": 40,
      "accepted": 30, "declined": 5, "pending": 5, "expectedAttendees": 30 }
  ]
}
```
- `responseRate`/`checkInRate` = **doubles** (0 à 100), déjà arrondis à 2 décimales par le backend.

---

## 6. Catalogue des endpoints

> Légende : 🔓 = **public** (sans JWT) ; 🔐 = **JWT requis** ; « Permission » = permission **server-side** requise (sinon `403`). Chaque ressource est aussi **restreinte à l'organisation** de l'utilisateur connecté (cross-org → `403`).

### 6.1 Authentification
| Méthode | Chemin | Auth | Permission | Statuts |
|---|---|---|---|---|
| `POST` | `/auth/register` | 🔓 | — | 200 (LoginResponse), 400, 409 (email déjà utilisé) |
| `POST` | `/auth/login` | 🔓 | — | 200, 401 |
| `GET` | `/auth/me` | 🔐 | — (connecté) | 200, 401 |

### 6.2 Santé
| `GET` | `/health` | 🔓 | — | 200 |

### 6.3 Accès public invité (RSVP)
| Méthode | Path | Auth | Permission | Statuts |
|---|---|---|---|---|
| `GET` | `/api/public/invitations/{publicToken}` | 🔓 | — | 200, 404 (token inconnu / CANCELLED / EXPIRED / supprimé) |
| `POST` | `/api/public/invitations/{publicToken}/rsvp` | 🔓 | — | 200, 400, 404 |

Le `publicToken` est un jeton aléatoire de 32 caractères (imprévisible, unique). Le client ne peut **jamais** fournir guestId / weddingId / invitationId.

### 6.4 Mariages
| Méthode | URL | Permission | Statuts |
|---|---|---|---|
| `GET` | `/api/weddings` | `WEDDING_VIEW` | 200 (PageResponse) |
| `POST` | `/api/weddings` | `WEDDING_CREATE` | 201, 400 |
| `GET` | `/api/weddings/{id}` | `WEDDING_VIEW` | 200, 403, 404 |
| `PUT` | `/api/weddings/{id}` | `WEDDING_UPDATE` | 200, 400, 403 |
| `PUT` | `/api/weddings/{id}/status` | selon cible (`WEDDING_PUBLISH`…) | 200, 400, 409 |
| `DELETE` | `/api/weddings/{id}` | `WEDDING_DELETE` | 204, 403 |

### 6.5 Catégories d'invités
`GET/POST /api/weddings/{wid}/guest-categories` · `GET/PUT/DELETE /api/weddings/{wid}/guest-categories/{id}` — `CATEGORY_VIEW / CREATE / UPDATE / DELETE`. Statuts 200/201/204, 400, 404.

### 6.6 Invités
`GET/POST /api/weddings/{wid}/guests` · `GET/PUT/DELETE /api/weddings/{wid}/guests/{guestId}` — `GUEST_VIEW / _CREATE / _UPDATE / _DELETE`. `GET` liste paginée ; 409 si email déjà utilisé à la création.

### 6.7 Événements de mariage
`GET/POST /api/weddings/{wid}/events` · `GET/PUT/DELETE /api/weddings/{wid}/events/{eventId}` — `EVENT_VIEW / _CREATE / _UPDATE / _DELETE`.

